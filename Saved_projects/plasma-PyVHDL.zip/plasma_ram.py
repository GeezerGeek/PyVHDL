#-------------------------------------------------------------------------------
#
# plasma_ram.py - 1/7/2016
#
# Emulate a memory with 8K(8192) 32 bit words, and a UART data register
#
#-------------------------------------------------------------------------------

import sys, logging
 
# Simulator python file imports

from Sim.design_parser import Design, Parsing_Exception
from Sim.interp import Simulation
from Sim.vcd_dump import VCD_File
from Sim.PyModule import Delayed, Process, waitFor, waitOn 

#-------------------------------------------------------------------------------
#
#   port(
#   	CLK          : in  std_logic;
#   	RESET        : in std_logic;
#   		
#       MEM_BYTE_SEL : in  std_logic_vector(3 downto 0);
#       MEM_WRITE    : in  std_logic;
#       MEM_ADDRESS  : in  std_logic_vector(31 downto 0);
#       MEM_DATA_W   : in  std_logic_vector(31 downto 0);
#       MEM_DATA_R   : out std_logic_vector(31 downto 0);
#       MEM_PAUSE    : out std_logic
#   );
#
#-------------------------------------------------------------------------------

class MemoryEmulator(Process):

    def initialize(self):

        # Read MIPS instructions from a file of 32-bit hex values
        # starting at address 00000000.

        self.mem  = {}  # Memory implemented as a dict
        a         = 0	# Integer memory address

        #----------------------------------------------------
        # Test files are in the "Workspace/project" directory
        #----------------------------------------------------

        # file_name = 'test1_hex.txt'
        # file_name = 'test2_hex.txt'
        # file_name = 'test3_hex.txt'
        # file_name = 'test4_hex.txt'
        # file_name = 'test5_hex.txt'
        # file_name = 'test6_hex.txt'    	# sim.run_time(18750)        
        # file_name = 'test7_hex.txt'    	# sim.run_time(10000)         
        # file_name = 'test8_hex.txt'    	# sim.run_time(14300) 
        file_name = 'test9_hex.txt'    	# sim.run_time(33500) 
        # file_name = 'test9B_hex.txt'    	# sim.run_time(14400) 

        #----------------------------------------------------
		#
		# Read hex file 
		
        hex_file = open(file_name, 'r')
        print '  test file: %s' % file_name
                
        while True:
    
            value = hex_file.readline()
            if not value:
            	# At EOF    
                hex_file.close()
                break
    
            # Strip /n
            value = value[:-1]

            # Skip empty lines
            if len(value.replace(' ', '')) == 0:
                continue
                
            self.mem[a] = '0x%s' % value
            a += 4
            
        hex_file.close()
        
        #----------------------------------------------------
		#
        # Open file for UART messages
        
        self.uart_file = open('uart.txt', 'w') 

    #----
  
    def run(self, P, S):

        UART_ADRS   = int('20000000',16)
        MEM_TOP     = int('1FFF', 16) 
        P.MEM_PAUSE = 0
                        
        while True:
    
            # Convert binary address to an integer
            # NOTE that lower 2 bits of address are for byte select and
            # SHOULD BE IGNORED!

            adrs_str = str(P.MEM_ADDRESS)
            try:
                adrs = int(adrs_str,2) & 0xFFFFFFFC
            
            except ValueError:
                # adrs_str contains "U", "X", ...
                print '**** bogus MEM_ADDRESS: %s' % adrs_str
                adrs = 0

            # PROCESS MEMORY WRITE
            
            if str(P.MEM_WRITE) == '1':
            
                print '**** MEM_BYTE_SEL: %s' % str(P.MEM_BYTE_SEL)

                if adrs == UART_ADRS:
                 
                    # Writing to the UART 

                    char = int(str(P.MEM_DATA_W)[-8:], 2)

                    if char == 0x1C:
                        # End of file marker
                        self.uart_file.close()

                    else:
                        print '**** UART write: %02X' % char
                        self.uart_file.write(chr(char))

                    self.waitOn(P.MEM_ADDRESS)
                    continue

                else:

                    # Writing to 8K memory

                    # Check address against memory size    
                    if adrs > MEM_TOP:
                        print '**** Memory address 0x%08X > 0x1FFF' % adrs
                        raise ValueError, 'Memory address 0x%08X > 0x1FFF' % adrs            

                    try:
                        data = self.mem[adrs].upper()[2:]                
                    except KeyError:
                        # Un-initialized memory
                        data = '00000000'

                    value   = ''
                    sel     = str(P.MEM_BYTE_SEL)
                    wr_data = '%08X' % int(str(P.MEM_DATA_W), 2)

                    for s1,x1,x2 in [(sel[i]=='1', i*2, i*2+2) for i in range(4)]:
                        if s1:
                            value += wr_data[x1:x2]
                        else:
                            value += data[x1:x2]

                    print '**** MEMORY WRITE: value %s, address 0x%08X' % (value, adrs)
                    self.mem[adrs] =  '0x%s' % value
                                             
            # PROCESS MEMORY READ
            else:

                # Check address against memory size    
                if adrs > MEM_TOP:
                    print '**** Memory address 0x%08X > 0x1FFF' % adrs
                    raise ValueError, 'Memory address 0x%08X > 0x1FFF' % adrs            
                try:
                    value = self.mem[adrs]
                
                except KeyError:
                    raise ValueError, '*** Memory address 0x%08X un-initialized' % adrs
                    # pass
                                        
                try:
                    a = int(adrs_str,2)            
                except ValueError:
                    a = 0

                print '**** MEMORY READ: value 0x%s, address 0x%08X @ %.2f' % (value.upper()[2:], a, self.sim.time)            
                P.MEM_DATA_R = value

            self.waitOn(P.MEM_ADDRESS)
                 
#-------------------------------------------------------------------------------
#
# Main

def setup(tb, P):
       
    tb.addProcess(MemoryEmulator())
   