#-------------------------------------------------------------------------------
#
# reg_block.py - 12/28/2015
#
# Registers for plasma CPU design
#
#-------------------------------------------------------------------------------
 
# Simulator python file imports
from Sim.design_parser import Design, Parsing_Exception
from Sim.interp import Simulation
from Sim.vcd_dump import VCD_File
from Sim.PyModule import Delayed, Process, waitFor, waitOn 

from time import clock

#-------------------------------------------------------------------------------

registers = []
reg_names = ['zero','at','v0','v1','a0','a1','a2','a3',
             't0','t1','t2','t3','t4','t5','t6','t7',
             's0','s1','s2','s3','s4','s5','s6','s7',
             't8','t9','k0','k1','gp','sp','fp','ra']

#-------------------------------------------------------------------------------
#
#   port(
#		clk  	  : IN 	std_logic;						
#		reset	  : IN 	std_logic;
#		
#		addr_r1   : IN  std_logic_vector(4 downto 0);
#		addr_r2   : IN  std_logic_vector(4 downto 0);
#		addr_w    : IN  std_logic_vector(4 downto 0);
#		write_ena : IN  std_logic;
#		
#		rd_data1 : OUT std_logic_vector(31 downto 0);
#		rd_data2 : OUT std_logic_vector(31 downto 0);
#		wr_data  : IN  std_logic_vector(31 downto 0)		
#   );
#
#-------------------------------------------------------------------------------

# Process for read port 1

class Register_r1(Process):
    
     def run(self, P, S):

        global registers
        
        while True:

            self.waitOn(P.ADDR_R1)
            # print '**** reg_block.Register_r1: ADDR_R1 change: %s at %.2f' % (str(P.ADDR_R1), self.sim.time)

            adrs_str = str(P.ADDR_R1) 
            try:
                adrs     = int(adrs_str,2)
            except ValueError:
            	# adrs probably = 'UUUUU'
            	print '>>>> BAD ADDR_R1 = %s @ %.2f' % (adrs_str, self.sim.time) 
            	adrs = 0 # <--------------------<<< BOGUS!! 

            if adrs < 32:

            	value = registers[adrs]

                P.RD_DATA1 = registers[adrs]
                print '>>> RD_DATA1 %08X fr %s @ %.2f' % (int(value, 2), reg_names[adrs], self.sim.time)

            else:
                raise IndexError, 'Register r1 address > 31'

#-------------------------------------------------------------------------------

# Process for read port 2

class Register_r2(Process):
  
    def run(self, P, S):

        global registers, reg_names

        while True:
    
            self.waitOn(P.ADDR_R2)

            adrs_str = str(P.ADDR_R2) 
            try:
                adrs     = int(adrs_str,2)
            except ValueError:
            	# adrs probably = 'UUUUU'
            	print '>>>> Bad ADDR_R2 = %s' % adrs_str
            	adrs = 0 # <--------------------<<< BOGUS!! 

            if adrs < 32:

            	value = registers[adrs]
            	
                P.RD_DATA2 = value
                print '>>> RD_DATA2 %08X fr %s @ %.2f' % (int(value, 2), reg_names[adrs], self.sim.time)

            else:
                raise IndexError, 'Register r2 address > 31: %d, %03x' % (adrs, adrs)


#-------------------------------------------------------------------------------

# Process for write port

class Register_w(Process):

    def initialize(self):

        global registers, reg_names
 
        # fill registers with zeros
        for adrs in range(32):
            registers.append('00000000000000000000000000000000')
        # print '>>>> Registers cleared'
  
    def run(self, P, S):

        global registers, reg_names
           	
        while True:
    
            self.waitRising(P.CLK)
            if str(P.WRITE_ENA) == '1':

                adrs_str = str(P.ADDR_W) 
                adrs     = int(adrs_str,2)
                value    = str(P.WR_DATA)
                if adrs < 32:

                    print 'WRITE %08X to   %s @ %.2f ns' % (int(value, 2), reg_names[adrs], sim.time)
            	
            	    # Add a 5 ns tco
            	    waitFor(5)
 
                    # Update register file
                    registers[adrs] = value
                    
                    # Update RD_DATA1 if ADDR_W = ADDR_R1
                    if adrs_str == str(P.ADDR_R1):
            	        
                        P.RD_DATA1 = value
                    
                    # Update RD_DATA2 if ADDR_W = ADDR_R2
                    if adrs_str == str(P.ADDR_R2): 
                        P.RD_DATA2 = value
                else:
                    raise IndexError, 'Register address > 31'

#-------------------------------------------------------------------------------
#
# Main

def setup(tb, P):

    global sim
    sim = tb.sim

    tb.addProcess(Register_r1())
    tb.addProcess(Register_r2())
    tb.addProcess(Register_w())
        