#-------------------------------------------------------------------------------
#
# peripheral.py - 12/28/2015
#
# Peripherals for plasma design:
#
#  - clock
#  - reset
#
# Setup for VCD tracing
#
#-------------------------------------------------------------------------------

import sys, logging
 
# Simulator python file imports

from Sim.design_parser import Design, Parsing_Exception
from Sim.interp import Simulation
from Sim.vcd_dump import VCD_File
from Sim.PyModule import Delayed, Process, waitFor, waitOn 

from time import clock

#-------------------------------------------------------------------------------
#
#   port(
#   	clk          : out std_logic;
#   	reset        : out std_logic;
#   		
#       mem_address  : in std_logic_vector(31 downto 0);
#       mem_byte_sel : in std_logic_vector(3 downto 0);
#       mem_write    : in std_logic;
#       mem_data_w   : in std_logic_vector(31 downto 0);
#       mem_data_r   : out std_logic_vector(31 downto 0)
#   );
#
#-------------------------------------------------------------------------------
#
# Generate reset 

class ResetGen(Process):

	# Generate 225ns high-active reset pulse 

    def run(self, P, S):
    
        P.RESET = Delayed(1, 0)                
        waitFor(225)        
        P.RESET = Delayed(0, 0)

        waitFor()

#-------------------------------------------------------------------------------
#
# Main

def setup(tb, P):

    sim = tb.sim

    # print 'P: %s' % P.itemList
    
    # sim.VCD_Signals()
    sim.listVMs()
 
    # Setup clock and reset
    tb.addClock(P.CLK, 25.0, 25.0)
    tb.addProcess(ResetGen())
	
    vcd = sim.VCD_open('test.vcd')

    vcd.add('/reset')
    vcd.add('/clk')
    vcd.add('/mem_byte_sel')
    vcd.add('/mem_write')
        
    vcd.add('/mem_address')
    vcd.add('/mem_data_r')
    vcd.add('/mem_data_w')
    
    vcd.add('/t1_cpu/mem_source')
    vcd.add('/t1_cpu/u2_mem_ctrl/mem_state_reg')
    vcd.add('/t1_cpu/u2_mem_ctrl/opcode_reg')
    
    vcd.add('/t1_cpu/u4_reg_bank/write_enable')
    vcd.add('/t1_cpu/u8_mult/reg_b')
    vcd.add('/t1_cpu/u8_mult/reg_a')
    vcd.add('/t1_cpu/u8_mult/count_reg')
    vcd.add('/t1_cpu/a_busD')
    vcd.add('/t1_cpu/b_busD')
                    
    # sim.run_time(18750)			# For test 6
    # sim.run_time(14300)			# For test8
    sim.run_time(33500)			# For test 9
    # sim.run_time(14400)			# For test 9B
    
    